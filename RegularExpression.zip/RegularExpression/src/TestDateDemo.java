import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemo {

	public static void main(String[] args)
	{
		//1
		LocalDate today=LocalDate.now();
		System.out.println("Today Date : "+today);
		
		//2
		System.out.println("*****************");
		LocalDate myDOJ=LocalDate.of(2010,04,03);
		System.out.println("My date of joining "+myDOJ);
		
		//3
		System.out.println("*****************");
		String rishiDOJ="13-Dec-2017";
		
		DateTimeFormatter myFormat=
		DateTimeFormatter.ofPattern("dd-MMM-yyyy");	//jo format humne diya hai vo baatya hai
		LocalDate rishitaDOJ=LocalDate.parse(rishiDOJ,myFormat);
		System.out.println("Rishita DOJ = "+rishitaDOJ);

		///4
		System.out.println("************************************");
		DateTimeFormatter secondFormat=DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		String urDOJ= rishitaDOJ.format(secondFormat);
		System.out.println("------"+urDOJ);
		
		//difference between two date 
		System.out.println("***************************");
		System.out.println("Difference");
		Period period=Period.between(myDOJ, today);
		int years=period.getYears();
		int month=period.getMonths();
		int day=period.getDays();
		
		System.out.println("my Experience in CG is "+years +"Years : "+month+" Months : "+day+"Days : ");
	}

}
