//step-10

package com.cg.empmgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.service.EmpService;
import com.cg.empmgm.service.EmpServiceImpl;

public class EmpClient 
{
	
	static Scanner sc=null;	
	static EmpService empSer=null;
	
	public static void main(String[] args) 
	{
		empSer=new EmpServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		
		while(true)
		{
			System.out.println("What do you want to do ? ");
			System.out.println("1:Add Employee details\n"
								+"2:Fetch all employee details\n"
								+"3:Delete Employee Details\n"
								+"4:Update employee details\n");
			choice=sc.nextInt();
			switch(choice )
			{
				case 1:insertEmp();
						break;
				
				case 2:fetchAllEmp();
						break;
			
				case 3:delEmp();
						break;
				
				case 4:updateEmp();
						break;
				
				default: System.exit(0);
			}	//switch case end
			
		}//while loop end
		
	}//main ends here
	
	
	/************************Insert Employee Details***************************/
	public static void insertEmp()
	{
		System.out.println("Enter employee name: ");
		String enm=sc.next();
		float esl=0.0F;
		try 
		{
			if(empSer.validateName(enm))
			{
				System.out.println("Enter Salary :  ");
				esl=sc.nextFloat();
				
				Employee ee=new Employee();
				ee.setEmpName(enm);
				ee.setEmpSal(esl);
				
				int dataAdded=empSer.addEmp(ee);
				
				
				if(dataAdded==1)
				{
					System.out.println("emp data added :  ");
				}
				else
				{
					System.out.println("there may be some exception while addition ");
				}
			}
		} 
		catch (EmployeeException e) 
		{
			System.out.println(e.getMessage());
		}
	}
	
	/************************Fetch all data***************************/
	
	public static void fetchAllEmp()
	{
		try
		{
			ArrayList<Employee> empList=empSer.getAllEmp();
			for(Employee ee:empList)
			{
				System.out.println(ee);
			}
		}
		catch (EmployeeException e) 
		{
			System.out.println("Some Exception while fetching data ");
		}
		
	}
	
	/***************************************************/
	
	public static void delEmp()
	{
		System.out.println("Enter employee id to delete ");
		int eid=sc.nextInt();
		
		try 
		{
			int dataDelete=empSer.deleteEmp(eid);
			
			if(dataDelete==1)
			{
				System.out.println(" data deleted successfully");
			}
			else
			{
				System.out.println("there might be some exception");
			}
		}
		catch (EmployeeException e) 
		{
			System.out.println(e.getMessage());
		}
		
		
	}
	
	/***************************************************/
	
	public static void updateEmp()
	{
		
	}
	
	/***************************************************/
	
}
