//step-9
package com.cg.empmgm.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.dao.EmpDao;
import com.cg.empmgm.dao.empDaoImpl;
import com.cg.empmgm.exception.EmployeeException;

public class EmpServiceImpl implements EmpService
{
	EmpDao empDao=null;
	
	public EmpServiceImpl()
	{
		empDao=new empDaoImpl();
	}

	@Override
	public int addEmp(Employee emp) throws EmployeeException 
	{
		// TODO Auto-generated method stub
		return empDao.addEmp(emp);
	}

	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.getAllEmp();
	}

	@Override
	public int generateEmpId() throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.generateEmpId();
	}

	@Override
	public boolean validateDigit(int empId) throws EmployeeException 
	{
		String numPattern="[0-9]{4}";
		if(Pattern.matches(numPattern, new Integer(empId).toString()))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Only Mini 4 digit allowed in empid");
		}
	}

	@Override
	public boolean validateName(String empname) throws EmployeeException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, empname))
		{
			return true;
		}
		
		else
		{
			throw new EmployeeException("Only Characters allowed at start with"+
									"capital e.g. Rishita");
		}
		
	}

	@Override
	public int deleteEmp(int id) throws EmployeeException 
	{
		return empDao.DeleteEmp(id);
	}

}
