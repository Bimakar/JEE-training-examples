//step-7
package com.cg.empmgm.dao;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.util.DBUtil;

public class empDaoImpl implements EmpDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	

	@Override
	public int addEmp(Employee emp) throws EmployeeException 
	{
		String insertQry="INSERT into emp_142272(emp_id,emp_name,emp_sal)"+
							" VALUES( ?,?,?)";
		int dataAdded;
		try 
		{
			con=DBUtil.getCon();
			//System.out.println("conn *****************"+con);
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generateEmpId());
			pst.setString(2, emp.getEmpName());
			pst.setFloat(3,emp.getEmpSal());
			
			//pst.executeUpdate();
			dataAdded=pst.executeUpdate();
			
		}
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new EmployeeException(e.getMessage());
			}
			
		}
		
		return dataAdded;
	}

	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		ArrayList<Employee> empList=new ArrayList<Employee>();
		
		String selectQry="SELECT * FROM emp_142272";
		
		Employee ee=null;
		
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				ee=new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal"));
				empList.add(ee);
			}
		}
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new EmployeeException(e.getMessage());
			}
			
		}

		
		return empList;
	}

	@Override
	public int generateEmpId() throws EmployeeException	//this will generate empid we will call it in addEmp function
	{
		String qry="SELECT emp_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			rs.next();
			generatedVal=rs.getInt(1);
		}
		catch (Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		
		finally	//all the connection object must be closed i.e. pst,st,rs
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new EmployeeException(e.getMessage());
			}
			
		}
		
		return generatedVal;
	}
	
	//For Delete operation
	@Override
	public int DeleteEmp(int id) throws EmployeeException
	{
		String deleteQry="Delete from emp_142272 WHERE emp_id=?";
		int dataDelete;
		
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1, id);
			
			dataDelete=pst.executeUpdate();
		}
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new EmployeeException(e.getMessage());
			}
			
		}
		
		return dataDelete;
		
	}
	

}
