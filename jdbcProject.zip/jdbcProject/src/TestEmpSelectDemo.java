import java.sql.*;


public class TestEmpSelectDemo {

	public static void main(String[] args) 
	{
		//Load Oracle type 4 driver in memory
		Connection con=null; 		//step 4 con is variable can give any name
		//statement object step 5
		Statement st=null;
		//step 7
		ResultSet rs=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");		//step3
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
					"system","Capgemini123");	//step4
			st=con.createStatement();	//step5
			//can also write step 6 as;
			String selQuery="SELECT emp_id,emp_name,emp_sal FROM emp_142272";
			//st.executeQuery("SELECT")	//step6
			rs=st.executeQuery(selQuery);	//step 7
			
			/*rs.next();		//gives next value    step7
			System.out.println("ID \t NAME \t SALARY");
			System.out.println(rs.getInt("emp_id")+" \t "+
					rs.getString("emp_name")+" \t "+rs.getInt("emp_sal"));
			*/
			//to print all the records;
			
			while(rs.next())
			{
				System.out.println("ID \t NAME \t SALARY \t Date_of_joining");
				System.out.println(rs.getInt(1)+"\t"+
						rs.getString("emp_name")+"\t "+rs.getInt("emp_sal")/*+rs.getDate("emp_doj")*/);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
