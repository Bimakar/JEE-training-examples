import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpData2Demo {

	public static void main(String[] args)
	{
		Connection con=null; 
		Scanner sc=null;
		PreparedStatement pst;
		try 
		{
			sc=new Scanner(System.in);
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
					"system","Capgemini123");
			
			System.out.println(" Enter id : ");
			int empId=sc.nextInt();
			System.out.println(" Enter name : ");
			String empname=sc.next();
			System.out.println(" Enter Salary : ");
			float empsal=sc.nextFloat();
			
			String insertqry="INSERT INTO emp_142272 (emp_id,"+
								"emp_name,emp_sal)VALUES(?,?,?)";
			//'?' becoz  we are going to insert values during run time
			
			//assigning values which we are going to give . 1 is index of column 
			pst=con.prepareStatement(insertqry);
			pst.setInt(1, empId);
			pst.setString(2, empname);
			pst.setFloat(3, empsal);
			int dataAdded=pst.executeUpdate();
			
			System.out.println("data entered");
			
		}
		catch (Exception e)
		{
					e.printStackTrace();
		}	

	}

}


/*
 * Dynamic query becoz data we our entering through keyboard*/
