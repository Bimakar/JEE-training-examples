import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;


public class TestResultSetMetaDataDemo {

	public static void main(String[] args) 
	{
		Connection con=null; 
		Statement st=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM emp_142272");
			
			rsmd=rs.getMetaData();
			int columnCount=rsmd.getColumnCount();
			
			System.out.println("No of columns : "+columnCount);
			for(int i=1;i<columnCount;i++)
			{
				System.out.println(i+"Column name : "+rsmd.getColumnName(i));
				System.out.println(i+"Column type : "+rsmd.getColumnType(i));
				System.out.println(i+"Column type Name : "+rsmd.getColumnTypeName(i));
				System.out.println(i+"Column Label : "+rsmd.getColumnLabel(1));
				System.out.println("****************************");
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

}
