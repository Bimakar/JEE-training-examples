import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class TestEmpAddDemo {

	public static void main(String[] args) 
	{
		Connection con=null; 
		Statement st=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
					"system","Capgemini123");
			String insertqry="INSERT INTO emp_142272("
					+ "emp_id,emp_name,emp_sal) VALUES(666,'Nihit',2000)";
			st=con.createStatement();
			int data =st.executeUpdate(insertqry);	//return type of execute update is integer
			System.out.println("data inserted in table  "+data);
			
		}
		catch (Exception e)
		{
					e.printStackTrace();
		}	
	}

}
