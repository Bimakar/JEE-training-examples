import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpDataNDemo {

	public static void main(String[] args)
	{
	
		Connection con=null; 
		Scanner sc=null;
		PreparedStatement pst=null;
		
		int empId=0;
		String empname=" ";
		float empsal=0.0F;
		try 
		{
			sc=new Scanner(System.in);
			System.out.println("Enter how many records you want to enter ");
			int n=sc.nextInt();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
					"system","Capgemini123");
			
			String insertqry="INSERT INTO emp_142272 (emp_id,"+
					"emp_name,emp_sal)VALUES(?,?,?)";
			pst=con.prepareStatement(insertqry);
			for(int i=0;i<n;i++)
			{
				System.out.println(" Enter id : ");
				empId=sc.nextInt();
				System.out.println(" Enter name : ");
				empname=sc.next();
				System.out.println(" Enter Salary : ");
				empsal=sc.nextFloat();	
				
				pst.setInt(1, empId);
				pst.setString(2, empname);
				pst.setFloat(3, empsal);
				int dataAdded=pst.executeUpdate();
				System.out.println("data entered");
			}
				
			
			
		}
		catch (Exception e)
		{
					e.printStackTrace();
		}	

	}

}
