import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestMenuDrivenDemo {

	public static void main(String[] args) 
	{
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		PreparedStatement pst=null;
		Scanner sc=new Scanner(System.in);
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			 int empId=0;
			
			System.out.println("1.Select\t2.Particular emp\t3.Insert\t4.Update\t5.Delete\n");
			System.out.println("Enter your Choice : ");
			int choice=sc.nextInt();
			
			
			switch(choice)
			{
			case 1:System.out.println("you choose Select query");
					st=con.createStatement();		
					String selQuery="SELECT emp_id,emp_name,emp_sal FROM emp_142272";
					rs=st.executeQuery(selQuery);
					
					System.out.println("ID \t NAME \t SALARY");
					while(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t"+
								rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
					}
					break;
			case 2:	System.out.println("You choose for particular Query");
					System.out.println(" Enter id : ");
					empId=sc.nextInt();
					st=con.createStatement();		
					String selQuery1="SELECT emp_id,emp_name,emp_sal FROM emp_142272 where empId="+empId;
					rs=st.executeQuery(selQuery1);
					pst.setInt(1, empId);
					System.out.println("ID \t NAME \t SALARY");
					rs.next();
					System.out.println(rs.getInt(1)+"\t"+
								rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
					break;
							
			case 3:System.out.println("You choose Insert Query");	
					System.out.println(" Enter id : ");
					empId=sc.nextInt();
					System.out.println(" Enter name : ");
					String empname=sc.next();
					System.out.println(" Enter Salary : ");
					float empsal=sc.nextFloat();
					
					st=con.createStatement();
					String insertqry="INSERT INTO emp_142272 (emp_id,"+
										"emp_name,emp_sal)VALUES(?,?,?)";
					pst=con.prepareStatement(insertqry);
					
					pst.setInt(1, empId);
					pst.setString(2, empname);
					pst.setFloat(3, empsal);
					int dataAdded=pst.executeUpdate();
					
					System.out.println("data entered"+dataAdded);
					System.out.println("ID \t NAME \t SALARY");
					while(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t"+
								rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
					}
					
					break;
			case 4:System.out.println("You choose Update Query");
					String updateqry="UPDATE emp_142272 SET emp_sal = emp_sal+10000 where emp_sal<15000";
					pst=con.prepareStatement(updateqry);
					pst.executeUpdate(updateqry);
					System.out.println("********************updated***************");
					System.out.println("Update done ");
					System.out.println("ID \t NAME \t SALARY");
					while(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t"+
								rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
					}
					break;
			case 5:System.out.println("you choose Delete Query ");
					System.out.println("enter emp ID to delete : ");
					empId=sc.nextInt();
					String deleteqry="Delete from emp_142272 where emp_id="+empId;
					pst=con.prepareStatement(deleteqry);
					pst.executeUpdate(deleteqry);
					System.out.println("deletion complete ");
					System.out.println("ID \t NAME \t SALARY");
					while(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t"+
								rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
					}
					break;
			default:System.out.println("you are out");
						break;
		
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

}
