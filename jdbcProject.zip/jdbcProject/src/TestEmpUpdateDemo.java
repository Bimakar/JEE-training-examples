import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class TestEmpUpdateDemo {

	public static void main(String[] args)
	{
		Connection con=null;
		PreparedStatement pst=null;
		System.out.println("*************start****************");
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
					"system","Capgemini123");
			String updateqry="UPDATE emp_142272 SET emp_sal = emp_sal+10000 where emp_sal<20000";
			pst=con.prepareStatement(updateqry);
			pst.executeUpdate(updateqry);
			System.out.println("********************updated***************");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
