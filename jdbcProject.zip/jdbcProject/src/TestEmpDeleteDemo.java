import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class TestEmpDeleteDemo {

	public static void main(String[] args) 
	{
		Connection con=null; 
		Scanner sc=null;
		PreparedStatement pst=null;
		
		int empId=0;
		String empname=" ";
		float empsal=0.0F;
		try
		{
			sc= new Scanner(System.in);
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
					"system","Capgemini123");
			empId=sc.nextInt();
			
			String deleteqry="Delete from emp_142272 where emp_id="+empId;
			
				pst=con.prepareStatement(deleteqry);
				pst.executeUpdate(deleteqry);
			}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		//empId=sc.nextInt();
		System.out.println("record deleted ");
	}

}
