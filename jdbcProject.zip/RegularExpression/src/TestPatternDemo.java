import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TestPatternDemo {

	public static void main(String[] args) 
	{
		//1
		String inputStr="Test String";
		String patern="Test String";
		boolean patternMatched = Pattern.matches(patern, inputStr);
		System.out.println(patternMatched);
		System.out.println("***********************");
		
		//2
		String inputStr1="Shop,Mop,Hopping,Chopping";
		Pattern pattern= Pattern.compile("hop"); 	//case sensitive that is why 
		Matcher matcher=pattern.matcher(inputStr1);
		//System.out.println("  yo   "matcher.matches());
		while(matcher.find())
		{
			System.out.println(matcher.group()+" : "+matcher.start()+" : "+matcher.end());
		}
		
		///3
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Ur Mobile No");
		String mobile=sc.next();
		String mobilepattern="[7-9][0-9]{9}";
		
		if(Pattern.matches(mobilepattern, mobile))
		{
			System.out.println("Valid mobile number ");
		}
		else
		{
			System.out.println("Only 10 digits mobile number which starts with 7 8 9 allowed");
		}
			
		
		
		
	}

}
