package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.BillDetails;
import com.cg.excepton.AllException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;


@WebServlet("/EBillServlet")
public class EBillServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	ServletConfig cg=null;  
	
	
    public EBillServlet() 
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		EBillService eser=null;
		eser=new EBillServiceImpl();
		
		PrintWriter out=response.getWriter();
		String action=request.getParameter("action");
		String action1=request.getParameter("action");
		
		String unm=request.getParameter("txtName");
		String pwd=request.getParameter("txtPwd");
		
		/*************************************Login Page validation*****************************/
		if(action.equals("UserInfo"))
		{
			try
			{
				if((unm.equals("admin")) && (pwd.equals("admin")))
				{
					response.sendRedirect("/Lab5.1WebProject/Html/User_Info.html");
				}
				else
				{
					throw new AllException("Login Credential are wrong");
				}
				
			}
			catch (AllException e) 
			{
				request.setAttribute("ErrorMsgObj", e.getMessage());
				RequestDispatcher rdError = request.getRequestDispatcher("ErrorPage");
				rdError.forward(request, response);
			}
		
			
		}
		/*************************************Login Page validation End*****************************/
	
		/*************************************User Info Page validation*****************************/
		
		if(action1.equals("TakeValue"))
		{
			String cnum=request.getParameter("Cnumber");
			
			long consumer_num=Long.parseLong(cnum);
			
			String LastMonthMeterReading=request.getParameter("LastMonthMeterReading");
			String CurrentMonthMeterReading=request.getParameter("CurrentMonthMeterReading");
			
			int lm=Integer.parseInt(LastMonthMeterReading);
			int cm=Integer.parseInt(CurrentMonthMeterReading);
			
			//System.out.println("1st");
			
			try 
			{
				
				if(eser.validateConsumerNum(consumer_num))
				{
					//System.out.println("zero");
					if(lm<cm)
					{
						out.println("<h2><b>Welcome "+eser.getConsumerDetails(consumer_num)+"</b></h2>");
						
						out.println("<h1><b>Electricity bill for consumer number -  "
										+consumer_num+" is</b></h1>");
						
						float unitconsumed=0;
						unitconsumed=cm-lm;
						float netAmount=(float)(unitconsumed*1.15)+100; 
						out.println("<b><br/>Unit Consumed :: "
								+unitconsumed+"</b>");
						out.println("<br/><b>Net Amount :: "+netAmount+"</b>");
						
						
						
						BillDetails bd=new BillDetails();
						bd.setConsumer_num(consumer_num);;
						bd.setCur_reading(cm);
						bd.setUnitConsumed(unitconsumed);
						bd.setNetAmount(netAmount);
						
						int dataAdded=eser.addBillDetails(bd);
						if(dataAdded==1)
						{
							out.println(" data added ");
						}
						
						
					}
					else
					{
						out.println("not");
					}
					
				}
				else
				{
					out.println(" consumer id is wrong ");
				}
			}
			catch (AllException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		/*************************************User Info Page validation End*****************************/
		
		/*else
		{
			out.println("Failed");
		}*/
		
	}
	
	

}
