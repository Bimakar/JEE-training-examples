package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.excepton.AllException;

public interface EBillService 
{
	public ArrayList<Long> getConsumerNum() throws AllException;
	
	public boolean  validateConsumerNum(long consumer_num) throws AllException;
	
	public String getConsumerDetails(long consumer_num) throws AllException;
	
	public int addBillDetails(BillDetails bd) throws AllException; 
}
