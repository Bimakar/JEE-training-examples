package com.cg.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.cg.dao.EBillDao;
import com.cg.dao.EBillDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.excepton.AllException;

public class EBillServiceImpl implements EBillService
{
	
	EBillDao edao=null;
	
	public EBillServiceImpl()
	{
		edao=new EBillDaoImpl();
	}
	
	@Override
	public ArrayList<Long> getConsumerNum() throws AllException 
	{
		return edao.getConsumerNum();
	}

	@Override
	public boolean validateConsumerNum(long consumer_num) throws AllException 
	{
		int count=0;
		Iterator it=edao.getConsumerNum().iterator();
		
		//System.out.println("3rd");
		
		while(it.hasNext())
		{
			long cnum=(long)it.next();
			if(consumer_num == cnum)
			{
				count=1;
				break;
			}
		}
		if(count==1)
		{
			System.out.println("2nd");
			return true;
		}
		else
		{
			throw new AllException("consumer  number not valid ");
		}
	}

	@Override
	public String getConsumerDetails(long consumer_num) throws AllException 
	{
		return edao.getConsumerDetails(consumer_num);
	}

	@Override
	public int addBillDetails(BillDetails bd) throws AllException
	{
		return edao.addBillDetails(bd);
	}

	
	
}
