package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.excepton.AllException;

public interface EBillDao 
{
	public ArrayList<Long> getConsumerNum() throws AllException;
	
	public String getConsumerDetails(long consumer_num) throws AllException;
	
	public int addBillDetails(BillDetails bd) throws AllException; 
	
	public int generateBillId() throws AllException;

}
