package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.excepton.AllException;
import com.cg.util.DBUtil;

public class EBillDaoImpl implements EBillDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	
	/***************************************************************************************/
	
	@Override
	public ArrayList<Long> getConsumerNum() throws AllException
	{
		ArrayList<Long> consumerList=new ArrayList<Long>();
		
		String selectQry="SELECT consumer_num FROM Consumers";

		
		//System.out.println("2nd");
		
		try 
		{
			con=DBUtil.getConn();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				consumerList.add(rs.getLong("consumer_num"));
			}
			System.out.println("3rd");
		}
		catch (Exception e) 
		{
			throw new AllException(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new AllException(e.getMessage());
			}
			
		}
		return consumerList;
	}

	/***************************************************************************************/
	
	@Override
	public String getConsumerDetails(long consumer_num) throws AllException 
	{
		String Selectqry="SELECT consumer_name FROM Consumers WHERE consumer_num=?";
		
		String consumer_name=null;
	
		try 
		{
			con=DBUtil.getConn();
			pst=con.prepareStatement(Selectqry);
			pst.setLong(1,consumer_num );
			rs=pst.executeQuery();
			rs.next();
			consumer_name=rs.getString("consumer_name");
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return consumer_name;
	}

	
	/***************************************************************************************/
	
	@Override
	public int addBillDetails(BillDetails bd) throws AllException 
	{
		String Insrtqry="INSERT INTO billdetails VALUES(?,?,?,?,?,SYSDATE)";
		int dataAdded;
		
		try 
		{
			con=DBUtil.getConn();
			pst=con.prepareStatement(Insrtqry);
			pst.setInt(1, generateBillId());
			pst.setLong(2, bd.getConsumer_num());
			pst.setFloat(3, bd.getCur_reading());
			pst.setFloat(4, bd.getUnitConsumed());
			pst.setFloat(5, bd.getNetAmount());
			
			dataAdded=pst.executeUpdate();	
			
		}
		catch (Exception e) 
		{
			throw new AllException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new AllException(e.getMessage());
			}
	}
		return dataAdded;
	}
	
	/***************************************************************************************/

	@Override
	public int generateBillId() throws AllException 
	{
		String qry="SELECT seq_bill_num.NEXTVAL FROM DUAL";	
		int generatedVal;
		

		try
		{
			con=DBUtil.getConn();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			rs.next();
			generatedVal=rs.getInt(1);
			
		}
		catch (Exception e) 
		{
			throw new AllException(e.getMessage());
		} 
		
		finally	
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new AllException(e.getMessage());
			}
			
		}
		
		return generatedVal;
	}
	
}
