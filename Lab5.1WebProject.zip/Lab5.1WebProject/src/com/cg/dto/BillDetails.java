package com.cg.dto;

import java.time.LocalDate;

public class BillDetails 
{
	private int bill_num;
	private long consumer_num;
	private float cur_reading;
	private float unitConsumed;
	private float netAmount;
	private LocalDate bill_date;
	
	public int getBill_num() 
	{
		return bill_num;
	}
	public void setBill_num(int bill_num) 
	{
		this.bill_num = bill_num;
	}
	
	public long getConsumer_num() 
	{
		return consumer_num;
	}
	public void setConsumer_num(long consumer_num) 
	{
		this.consumer_num = consumer_num;
	}
	
	public float getCur_reading() 
	{
		return cur_reading;
	}
	public void setCur_reading(float cur_reading) 
	{
		this.cur_reading = cur_reading;
	}
	
	public float getUnitConsumed() 
	{
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) 
	{
		this.unitConsumed = unitConsumed;
	}
	
	public float getNetAmount() 
	{
		return netAmount;
	}
	public void setNetAmount(float netAmount) 
	{
		this.netAmount = netAmount;
	}
	
	public LocalDate getBill_date() 
	{
		return bill_date;
	}
	public void setBill_date(LocalDate bill_date) 
	{
		this.bill_date = bill_date;
	}
	
	public BillDetails() 
	{
		super();
	}
	public BillDetails(int bill_num, long consumer_num, float cur_reading,
			float unitConsumed, float netAmount, LocalDate bill_date)
	{
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.bill_date = bill_date;
	}
		
}
