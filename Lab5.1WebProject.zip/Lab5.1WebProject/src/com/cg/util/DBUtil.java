package com.cg.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.excepton.AllException;



public class DBUtil 
{
	public static Connection getConn() throws AllException
	{
		Connection con=null;
		/*con=DriverManager.getConnection
				("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
				*/
		InitialContext context;
		try
		{
			context = new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return con;
	}
}
